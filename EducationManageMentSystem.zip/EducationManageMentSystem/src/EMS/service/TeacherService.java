package EMS.service;

import EMS.domain.Teacher;
import EMS.utils.PageBean;

import java.util.List;

/**
 * Created by Administrator on 2017/6/18.
 */
public interface TeacherService {
    public void pageQuery(PageBean pageBean);

    public List<Teacher> findListNoStatus();

    public void save(Teacher model, String[] roleIds);
}
