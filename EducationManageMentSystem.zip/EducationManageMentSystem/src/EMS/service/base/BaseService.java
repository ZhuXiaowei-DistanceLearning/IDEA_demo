package EMS.service.base;

/**
 * Created by Administrator on 2017/6/17.
 */
public interface BaseService {
}
