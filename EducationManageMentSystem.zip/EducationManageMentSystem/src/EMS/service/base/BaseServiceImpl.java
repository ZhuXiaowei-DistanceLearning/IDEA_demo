package EMS.service.base;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Created by Administrator on 2017/6/17.
 */
@Service
@Transactional
public class BaseServiceImpl implements BaseService {

}
