package EMS.service;

import EMS.domain.Nature;

import java.util.List;

/**
 * Created by Administrator on 2017/6/19.
 */
public interface NatureService {
    public List<Nature> findAll();
}
