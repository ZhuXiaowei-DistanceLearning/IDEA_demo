package EMS.service;

import EMS.domain.Classes;
import EMS.utils.PageBean;
import EMS.web.action.base.BaseAction;

/**
 * Created by Administrator on 2017/6/17.
 */
public interface ClassesSerivce {

    public void pageQuery(PageBean pageBean);

    public void save(Classes model);

    public void deleteBatch(String ids);

    public Classes findById(String id);
}
