package EMS.service;

import EMS.domain.Section;

import java.util.List;

/**
 * Created by Administrator on 2017/6/18.
 */
public interface SectionService {
    public List<Section> findAll();
}
