package EMS.service;

import EMS.domain.Specialty;
import EMS.utils.PageBean;

import java.util.List;

/**
 * Created by Administrator on 2017/6/17.
 */
public interface SpecialtyService {
    public void add(Specialty model);

    public void pageQuery(PageBean pageBean);

    public void update(Specialty model);

    public void deleteBatch(String id);

    public List<Specialty> listajax();
}
