package EMS.service;

import EMS.domain.Student;
import EMS.utils.PageBean;

import java.util.List;

/**
 * Created by Administrator on 2017/6/17.
 */
public interface StudentService {
    public void saveBatch(List<Student> student);

    public void pageQuery(PageBean pageBean);

    public List<Student> findAll();

    public List<Student> findStudentById(PageBean pageBean, String id);

    public void addStudentAbenst(Integer absent, String[] studentIds);

}
