package EMS.service;

import EMS.domain.Score;
import EMS.utils.PageBean;

import java.util.List;

/**
 * Created by Administrator on 2017/6/20.
 */
public interface ScoreService {
    public void save(Score model);

    public List<Score> findStudent(String id);

    public List<Score> findClassesStudent(PageBean pageBean, String studentId);

    public Score findById(String studentId);

    public void saveScore(Score model);

    public List<Score> findAllCourseByStudentId(String sid);

}
