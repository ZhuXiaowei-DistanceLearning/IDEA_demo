package EMS.service.impl;

import EMS.dao.ScoreDao;
import EMS.domain.Score;
import EMS.domain.ScoreId;
import EMS.service.ScoreService;
import EMS.utils.PageBean;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by Administrator on 2017/6/20.
 */
@Service
@Transactional
public class ScoreServiceImpl implements ScoreService {
    @Autowired
    private ScoreDao scoreDao;

    @Override
    public void save(Score model) {
        scoreDao.save(model);
    }

    @Override
    public List<Score> findStudent(String id) {
        DetachedCriteria detachedCriteria = DetachedCriteria.forClass(Score.class);
        DetachedCriteria student = detachedCriteria.add(Restrictions.eq("id.course.id", id));
        return scoreDao.findByCriteria(detachedCriteria);
    }

    @Override
    public List<Score> findClassesStudent(PageBean pageBean, String studentId) {
        return scoreDao.findClassesStudent(pageBean, studentId);
    }

    @Override
    public Score findById(String studentId) {
        return scoreDao.findById(studentId);
    }

    @Override
    public void saveScore(Score model) {
        scoreDao.saveOrUpdate(model);
    }

    @Override
    public List<Score> findAllCourseByStudentId(String sid) {
        DetachedCriteria detachedCriteria = DetachedCriteria.forClass(Score.class);
        detachedCriteria.add(Restrictions.eq("id.student.sid", sid));
        return scoreDao.findByCriteria(detachedCriteria);
    }
}
