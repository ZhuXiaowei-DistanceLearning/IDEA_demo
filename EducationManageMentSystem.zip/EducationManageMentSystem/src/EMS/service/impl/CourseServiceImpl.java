package EMS.service.impl;

import EMS.dao.CourseDao;
import EMS.domain.Course;
import EMS.service.CourseService;
import EMS.utils.PageBean;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by Administrator on 2017/6/18.
 */
@Service
@Transactional
public class CourseServiceImpl implements CourseService {
    @Autowired
    private CourseDao courseDao;

    @Override
    public void add(Course model) {
        courseDao.save(model);
    }

    @Override
    public List<Course> findCourseByteacherId(PageBean pageBean, String tid) {
        return courseDao.findCourseByteacherId(pageBean, tid);
    }

    @Override
    public void addPage(int i, String id) {
        courseDao.executeUpdate("course.add", i, id);
    }

    @Override
    public Course findById(String courseid) {
        return courseDao.findById(courseid);
    }

}
