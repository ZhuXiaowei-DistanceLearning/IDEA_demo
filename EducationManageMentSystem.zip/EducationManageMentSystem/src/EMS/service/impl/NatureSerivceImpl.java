package EMS.service.impl;

import EMS.dao.NatureDao;
import EMS.domain.Nature;
import EMS.service.NatureService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by Administrator on 2017/6/19.
 */
@Service
@Controller
public class NatureSerivceImpl implements NatureService {
    @Autowired
    private NatureDao natureDao;

    @Override
    public List<Nature> findAll() {
        return natureDao.findAll();
    }
}
