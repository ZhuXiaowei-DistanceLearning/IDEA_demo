package EMS.service.impl;

import EMS.dao.WeekDao;
import EMS.domain.Week;
import EMS.service.WeekService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by Administrator on 2017/6/18.
 */
@Service
@Transactional
public class WeekServiceImpl implements WeekService {
    @Autowired
    private WeekDao weekDao;

    @Override
    public List<Week> findAll() {
        return weekDao.findAll();
    }
}
