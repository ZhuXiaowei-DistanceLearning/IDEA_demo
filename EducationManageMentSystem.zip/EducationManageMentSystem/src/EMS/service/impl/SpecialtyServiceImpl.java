package EMS.service.impl;

import EMS.dao.SpecialtyDao;
import EMS.domain.Specialty;
import EMS.service.SpecialtyService;
import EMS.utils.PageBean;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by Administrator on 2017/6/17.
 */
@Service
@Transactional
public class SpecialtyServiceImpl implements SpecialtyService {
    @Autowired
    private SpecialtyDao specialtyDao;

    @Override
    public void add(Specialty model) {
        specialtyDao.save(model);
    }

    @Override
    public void pageQuery(PageBean pageBean) {
        this.specialtyDao.pageQuery(pageBean);
    }

    @Override
    public void update(Specialty model) {
        specialtyDao.update(model);
    }

    @Override
    public void deleteBatch(String id) {
        String[] split = id.split(",");
        for (String ids : split) {
            specialtyDao.executeUpdate("specialty.delete", ids);
        }
    }

    @Override
    public List<Specialty> listajax() {
        DetachedCriteria detachedCriteria = DetachedCriteria.forClass(Specialty.class);
        detachedCriteria.add(Restrictions.ne("status", "1"));
        return specialtyDao.findByCriteria(detachedCriteria);
    }

}
