package EMS.service.impl;

import EMS.dao.TeacherDao;
import EMS.domain.Role;
import EMS.domain.Teacher;
import EMS.service.TeacherService;
import EMS.utils.PageBean;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by Administrator on 2017/6/18.
 */
@Service
@Transactional
public class TeacherServiceImpl implements TeacherService {
    @Autowired
    private TeacherDao teacherDao;

    @Override
    public void pageQuery(PageBean pageBean) {
        teacherDao.pageQuery(pageBean);
    }

    @Override
    public List<Teacher> findListNoStatus() {
        DetachedCriteria detachedCriteria = DetachedCriteria.forClass(Teacher.class);
        detachedCriteria.add(Restrictions.ne("status", "1"));
        return teacherDao.findByCriteria(detachedCriteria);
    }

    @Override
    public void save(Teacher model, String[] roleIds) {
        teacherDao.save(model);
        for (String id : roleIds) {
            Role role = new Role(id);
            model.getRoles().add(role);
        }
    }
}
