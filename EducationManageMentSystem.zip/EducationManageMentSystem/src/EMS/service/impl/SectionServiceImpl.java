package EMS.service.impl;

import EMS.dao.SectionDao;
import EMS.domain.Section;
import EMS.service.SectionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by Administrator on 2017/6/18.
 */
@Service
@Transactional
public class SectionServiceImpl implements SectionService {
    @Autowired
    protected SectionDao sectionDao;

    @Override
    public List<Section> findAll() {
        return sectionDao.findAll();
    }
}
