package EMS.service.impl;

import EMS.dao.UserDao;
import EMS.domain.Role;
import EMS.domain.User;
import EMS.service.UserService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;

/**
 * Created by Administrator on 2017/6/16.
 */
@Service
@Transactional
public class UserServiceImpl implements UserService {
    @Resource
    private UserDao userDao;

    @Override
    public User login(User user) {
        return userDao.login(user.getUsername(), user.getPassword());
    }

    @Override
    public void editPassword(String password, String id) {
        userDao.executeUpdate(password, id);
    }

    @Override
    public void save(User model, String[] roleIds) {
        userDao.save(model);
        for (String roleId : roleIds) {
            Role role = new Role(roleId);
            model.getRoles().add(role);
        }
    }
}
