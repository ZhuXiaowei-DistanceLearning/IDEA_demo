package EMS.service.impl;

import EMS.dao.CollegeDao;
import EMS.domain.College;
import EMS.service.CollegeService;
import EMS.utils.PageBean;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by Administrator on 2017/6/17.
 */
@Service
@Transactional
public class CollegeServiceImpl implements CollegeService {

    @Autowired
    private CollegeDao collegeDao;

    @Override
    public void pageQuery(PageBean pageBean) {
        collegeDao.pageQuery(pageBean);
    }

    @Override
    public void save(College model) {
        collegeDao.save(model);
    }

    @Override
    public void delete(String ids) {
        String[] split = ids.split(",");
        for (String id : split) {
            collegeDao.executeUpdate("college.delete", id);
        }
    }

    @Override
    public void edit(College college) {
        collegeDao.update(college);
    }

    @Override
    public List<College> findListNostatus() {
        DetachedCriteria detachedCriteria = DetachedCriteria.forClass(College.class);
        detachedCriteria.add(Restrictions.ne("status", "1"));
        return collegeDao.findByCriteria(detachedCriteria);
    }
}
