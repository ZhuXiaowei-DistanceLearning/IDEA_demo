package EMS.service.impl;

import EMS.dao.RoleDao;
import EMS.domain.Function;
import EMS.domain.Role;
import EMS.service.RoleSerivce;
import EMS.utils.PageBean;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by Administrator on 2017/6/12.
 */
@Service
@Transactional
public class RoleServiceImpl implements RoleSerivce {
    @Resource
    private RoleDao roleDao;


    @Override
    public void save(Role model, String ids) {
        roleDao.save(model);
        String[] functionIds = ids.split(",");
        for (String fid : functionIds) {
            //角色关联权限
            Function function = new Function(fid);//托管
            model.getFunctions().add(function);
        }
    }

    @Override
    public void pageQuery(PageBean pageBean) {
        roleDao.pageQuery(pageBean);
    }

    @Override
    public List<Role> findAll() {
        return roleDao.findAll();
    }
}
