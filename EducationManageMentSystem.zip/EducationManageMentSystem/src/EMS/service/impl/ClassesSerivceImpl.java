package EMS.service.impl;

import EMS.dao.ClassesDao;
import EMS.domain.Classes;
import EMS.service.ClassesSerivce;
import EMS.utils.PageBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Created by Administrator on 2017/6/17.
 */
@Service
@Transactional
public class ClassesSerivceImpl implements ClassesSerivce {
    @Autowired
    private ClassesDao classesDao;

    @Override
    public void pageQuery(PageBean pageBean) {
        classesDao.pageQuery(pageBean);
    }

    @Override
    public void save(Classes model) {
        classesDao.save(model);
    }

    @Override
    public void deleteBatch(String ids) {
    }

    @Override
    public Classes findById(String id) {
        String[] split = id.split(",");
        for (String ids : split) {
            return classesDao.findById(ids);
        }
        return null;
    }
}
