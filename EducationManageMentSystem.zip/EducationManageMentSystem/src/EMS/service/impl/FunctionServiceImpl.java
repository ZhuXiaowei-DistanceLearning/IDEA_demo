package EMS.service.impl;

import EMS.dao.FunctionDao;
import EMS.domain.Function;
import EMS.domain.Student;
import EMS.domain.Teacher;
import EMS.domain.User;
import EMS.service.FunctionService;
import EMS.utils.BOSContext;
import EMS.utils.PageBean;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.Security;
import java.util.List;

/**
 * Created by Administrator on 2017/6/11.
 */
@Service
@Transactional
public class FunctionServiceImpl implements FunctionService {
    @Autowired
    private FunctionDao functionDao;

    public void pageQuery(PageBean pageBean) {
        functionDao.pageQuery(pageBean);
    }

    @Override
    public List<Function> findMenu() {
        Subject subject = SecurityUtils.getSubject();
        Object object = subject.getPrincipal();
        List<Function> list = null;
        if (object instanceof User) {
            list = functionDao.findAllMenu();
        } else if (object instanceof Teacher) {
            list = functionDao.findMenuByTeacherid(((Teacher) object).getTid());
        } else if (object instanceof Student) {
            list = functionDao.findMenuByStudentid(((Student) object).getSid());
        }
        return list;
    }

    @Override
    public List<Function> findAll() {
        return functionDao.findAll();
    }

    @Override
    public void save(Function model) {
        if (model.getFunction() != null && model.getFunction().getId().equals("")) {
            model.setFunction(null);
        }
        functionDao.save(model);
    }
}
