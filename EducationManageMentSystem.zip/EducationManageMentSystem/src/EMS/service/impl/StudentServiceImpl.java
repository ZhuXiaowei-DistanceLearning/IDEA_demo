package EMS.service.impl;

import EMS.dao.StudentDao;
import EMS.domain.Student;
import EMS.service.StudentService;
import EMS.utils.PageBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by Administrator on 2017/6/17.
 */
@Service
@Transactional
public class StudentServiceImpl implements StudentService {
    @Autowired
    private StudentDao studentDao;

    @Override
    public void saveBatch(List<Student> student) {
        for (Student model : student) {
            studentDao.saveOrUpdate(model);
        }
    }

    @Override
    public void pageQuery(PageBean pageBean) {
        studentDao.pageQuery(pageBean);
    }

    @Override
    public List<Student> findAll() {
        return studentDao.findAll();
    }

    @Override
    public List<Student> findStudentById(PageBean pageBean, String id) {
        return studentDao.findStudentById(pageBean, id);
    }

    @Override
    public void addStudentAbenst(Integer absent, String[] studentIds) {
        for (String id : studentIds) {
            Student student = studentDao.findById(id);
            int i = student.getAbsent();
            absent = i + 2;
            studentDao.executeUpdate("student.absent", absent, id);
        }
    }
}
