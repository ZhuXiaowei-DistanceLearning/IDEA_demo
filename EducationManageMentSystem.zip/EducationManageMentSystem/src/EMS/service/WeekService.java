package EMS.service;

import EMS.domain.Week;

import java.util.List;

/**
 * Created by Administrator on 2017/6/18.
 */
public interface WeekService {
    public List<Week> findAll();
}
