package EMS.service;

import EMS.domain.Course;
import EMS.domain.Score;
import EMS.utils.PageBean;

import java.util.List;

/**
 * Created by Administrator on 2017/6/18.
 */
public interface CourseService {
    public void add(Course model);

    public List<Course> findCourseByteacherId(PageBean pageBean, String tid);

    public void addPage(int i, String id);

    public Course findById(String courseid);
}
