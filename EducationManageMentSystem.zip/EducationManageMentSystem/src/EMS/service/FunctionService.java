package EMS.service;


import EMS.domain.Function;
import EMS.utils.PageBean;

import java.util.List;

/**
 * Created by Administrator on 2017/6/11.
 */
public interface FunctionService {
    public void pageQuery(PageBean pageBean);

    public List<Function> findMenu();

    public List<Function> findAll();

    public void save(Function model);
}
