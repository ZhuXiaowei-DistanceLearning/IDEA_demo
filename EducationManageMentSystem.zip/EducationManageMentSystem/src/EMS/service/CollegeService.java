package EMS.service;

import EMS.domain.College;
import EMS.domain.Specialty;
import EMS.utils.PageBean;
import EMS.web.action.base.BaseAction;

import java.util.List;

/**
 * Created by Administrator on 2017/6/17.
 */
public interface CollegeService {
    public void pageQuery(PageBean pageBean);

    public void save(College model);

    public void delete(String ids);

    public void edit(College college);

    public List<College> findListNostatus();

}
