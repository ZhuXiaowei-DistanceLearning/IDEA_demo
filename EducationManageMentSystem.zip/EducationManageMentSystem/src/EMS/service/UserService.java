package EMS.service;

import EMS.domain.User;

/**
 * Created by Administrator on 2017/6/16.
 */
public interface UserService {
    public User login(User user);

    public void editPassword(String password, String id);

    public void save(User model, String[] roleIds);
}
