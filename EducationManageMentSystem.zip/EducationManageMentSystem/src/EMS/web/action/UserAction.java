package EMS.web.action;

import EMS.domain.User;
import EMS.web.action.base.BaseAction;
import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.mgt.SecurityManager;
import org.apache.shiro.subject.Subject;
import org.apache.struts2.ServletActionContext;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import java.io.IOException;

/**
 * Created by Administrator on 2017/6/16.
 */
@Controller
@Scope("prototype")
public class UserAction extends BaseAction<User> {

    public String editPassword() throws IOException {
        User user = (User) ServletActionContext.getRequest().getSession().getAttribute("user");
        String flag = "1";
        try {
            userService.editPassword(model.getPassword(), user.getId());
        } catch (Exception e) {
            flag = "0";
        }
        ServletActionContext.getResponse().setContentType("text/html;charset=utf-8");
        ServletActionContext.getResponse().getWriter().print(flag);
        return NONE;
    }

    public String pageQuery() throws IOException {
        teacherService.pageQuery(pageBean);
        this.writePageBean2Json(pageBean, new String[]{"noticebills", "roles"});
        return NONE;
    }

    private String[] roleIds;

    /**
     * 添加用户
     */
    public String add() {
        userService.save(model, roleIds);
        return "list";
    }


    public String[] getRoleIds() {
        return roleIds;
    }

    public void setRoleIds(String[] roleIds) {
        this.roleIds = roleIds;
    }
}
