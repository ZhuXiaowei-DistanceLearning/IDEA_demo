package EMS.web.action;

import EMS.domain.Specialty;
import EMS.web.action.base.BaseAction;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import java.io.IOException;
import java.util.List;

/**
 * Created by Administrator on 2017/6/17.
 */
@Controller
@Scope("prototype")
public class SpecialtyAction extends BaseAction<Specialty> {

    public String pageQuery() throws IOException {
        specialtyService.pageQuery(pageBean);
        this.writePageBean2Json(pageBean, new String[]{"currentPage", "detachedCriteria", "pageSize", "classeses", "teachers", "specialties"});
        return NONE;
    }

    public String addSpecialty() {
        specialtyService.add(model);
        return "list";
    }

    public String updateSpecialty() {
        specialtyService.update(model);
        return "list";
    }

    private String ids;

    public void setIds(String ids) {
        this.ids = ids;
    }

    public String delete() {
        specialtyService.deleteBatch(ids);
        return "list";
    }

    public String listajax() throws IOException {
        List<Specialty> list = specialtyService.listajax();
        this.writeList2Json(list, new String[]{"classeses", "college"});
        return NONE;
    }
}
