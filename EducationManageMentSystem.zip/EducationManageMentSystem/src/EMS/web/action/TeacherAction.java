package EMS.web.action;

import EMS.domain.Teacher;
import EMS.web.action.base.BaseAction;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import java.io.IOException;
import java.util.List;

/**
 * Created by Administrator on 2017/6/18.
 */
@Controller
@Scope("prototype")
public class TeacherAction extends BaseAction<Teacher> {
    public String pageQuery() throws IOException {
        teacherService.pageQuery(pageBean);
        this.writePageBean2Json(pageBean, new String[]{"currentPage", "detachedCriteria", "pageSize", "courses", "college","roles"});
        return NONE;
    }

    public String listajax() throws IOException {
        List<Teacher> list = teacherService.findListNoStatus();
        this.writeList2Json(list, new String[]{"courses", "college","roles"});
        return NONE;
    }

    private String[] roleIds;

    /**
     * 添加用户
     */
    public String add() {
        teacherService.save(model, roleIds);
        return "list";
    }


    public String[] getRoleIds() {
        return roleIds;
    }

    public void setRoleIds(String[] roleIds) {
        this.roleIds = roleIds;
    }
}
