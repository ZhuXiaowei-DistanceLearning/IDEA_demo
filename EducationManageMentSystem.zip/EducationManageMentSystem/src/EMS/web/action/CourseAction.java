package EMS.web.action;

import EMS.domain.Course;
import EMS.domain.Score;
import EMS.domain.Student;
import EMS.domain.Teacher;
import EMS.web.action.base.BaseAction;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.apache.struts2.ServletActionContext;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import java.io.IOException;
import java.util.List;

/**
 * Created by Administrator on 2017/6/18.
 */
@Controller
@Scope("prototype")
public class CourseAction extends BaseAction<Course> {
    public String pageQuery() throws IOException {
        collegeService.pageQuery(pageBean);
        this.writePageBean2Json(pageBean, new String[]{"currentPage", "detachedCriteria", "pageSize", "scores", "teachers", "specialties", "courses", "roles"});
        return NONE;
    }

    public String add() {
        courseService.add(model);
        return "list";
    }

    public String findCourseByteacherId() throws IOException {
        Teacher teacher = (Teacher) ServletActionContext.getRequest().getSession().getAttribute("teacher");
        List<Course> list = courseService.findCourseByteacherId(pageBean, teacher.getTid());
        ServletActionContext.getRequest().getSession().setAttribute("courseAndStudent", list);
        this.writeList2Json(list, new String[]{"currentPage", "detachedCriteria", "pageSize", "scores", "college", "courses", "roles"});
        return NONE;
    }

    private String courseid;

    public void setCourseid(String courseid) {
        this.courseid = courseid;
    }

    public String addScore() throws IOException {
        Course addStudentScore = courseService.findById(courseid);
        ServletActionContext.getRequest().getSession().setAttribute("addStudentScore", addStudentScore);
        return "page";
    }
}
