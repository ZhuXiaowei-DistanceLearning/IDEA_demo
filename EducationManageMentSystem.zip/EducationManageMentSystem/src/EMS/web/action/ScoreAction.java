package EMS.web.action;

import EMS.domain.*;
import EMS.web.action.base.BaseAction;
import com.opensymphony.xwork2.ActionContext;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.apache.struts2.ServletActionContext;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import java.io.IOException;
import java.util.List;

/**
 * Created by Administrator on 2017/6/18.
 */
@Controller
@Scope("prototype")
public class ScoreAction extends BaseAction<Score> {
    private String ids;
    private Integer peoples;


    public void setIds(String ids) {
        this.ids = ids;
    }

    public void setPeoples(Integer peoples) {
        this.peoples = peoples;
    }

    public String save() {
        Subject subject = SecurityUtils.getSubject();
        Student student = (Student) subject.getPrincipal();
        Course course = new Course(ids);
        ScoreId scoreId = new ScoreId(student, course);
        model.setId(scoreId);
        try {
            scoreService.save(model);
        } catch (Exception e) {
            e.printStackTrace();
            this.addActionError(this.getText("usernamenotfound"));
            return "list";
        }
        int i = peoples + 1;
        courseService.addPage(i, ids);
        return "list";
    }

    private String studentId;

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String findStudent() throws IOException {
        List<Score> list = scoreService.findStudent(studentId);
        this.writeList2Json(list, new String[]{"course", "classes", "scores", "roles"});
        return NONE;
    }


    public String findClassesStudent() throws IOException {
        Course course = (Course) ServletActionContext.getRequest().getSession().getAttribute("addStudentScore");
        scoreService.findClassesStudent(pageBean, course.getId());
        this.writePageBean2Json(pageBean, new String[]{"nature", "teacher", "section", "week", "students", "scores", "roles", "classeses", "teachers", "specialties"});
        return NONE;
    }

    public String addStudentScore() {
        String peaceTime = model.getPeaceTime();
        String endTime = model.getEndTime();
        if (peaceTime.equals("A+") && endTime.equals("A+")) {
            model.setScore("A+");
        } else if (peaceTime.equals("A") && endTime.equals("A")) {
            model.setScore("A");
        } else if (peaceTime.equals("B+") && endTime.equals("B+")) {
            model.setScore("B+");
        } else if (peaceTime.equals("B") && endTime.equals("B")) {
            model.setScore("B");
        } else if (peaceTime.equals("C+") && endTime.equals("C+")) {
            model.setScore("C+");
        } else if (peaceTime.equals("C") && endTime.equals("C")) {
            model.setScore("C");
        } else if (peaceTime.equals("D+") && endTime.equals("D+")) {
            model.setScore("D");
        } else if (peaceTime.equals("D") && endTime.equals("D")) {
            model.setScore("D");
        } else if (peaceTime.equals("F") && endTime.equals("F")) {
            model.setScore("F");
        } else if (peaceTime.equals("F") && endTime.equals("A")) {
            model.setScore("F");
        }
        scoreService.saveScore(model);
        return "score";
    }

    public String findIdExist() throws IOException {
        Student student = (Student) ServletActionContext.getRequest().getSession().getAttribute("student");
        String flag = "1";
        List<Score> exit = scoreService.findStudent(ids);
        for (Score score : exit) {
            if (score.getId().getStudent().getSid().equals(student.getSid())) {
                ServletActionContext.getResponse().getWriter().print(flag);
                return NONE;
            } else {
                flag = "0";
                ServletActionContext.getResponse().getWriter().print(flag);
                return NONE;
            }
        }
        return NONE;
    }

    public String findAllCourseByStudentId() {
        Subject subject = SecurityUtils.getSubject();
        Student student = (Student) subject.getPrincipal();
        List<Score> list = scoreService.findAllCourseByStudentId(student.getSid());
        ActionContext.getContext().put("allCourse", list);
        return "findCourse";
    }
}
