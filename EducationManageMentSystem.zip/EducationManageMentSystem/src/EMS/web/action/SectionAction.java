package EMS.web.action;

import EMS.domain.Section;
import EMS.web.action.base.BaseAction;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import java.io.IOException;
import java.util.List;

/**
 * Created by Administrator on 2017/6/18.
 */
@Controller
@Scope("prototype")
public class SectionAction extends BaseAction<Section> {
    public String listajax() throws IOException {
        List<Section> list = sectionService.findAll();
        this.writeList2Json(list, new String[]{"courses"});
        return NONE;
    }
}
