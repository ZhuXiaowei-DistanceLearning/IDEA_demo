package EMS.web.action;

import EMS.domain.Student;
import EMS.domain.Teacher;
import EMS.domain.User;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.apache.struts2.ServletActionContext;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import javax.annotation.Resource;

/**
 * Created by Administrator on 2017/6/19.
 */
@Controller
@Scope("prototype")
public class LoginAction extends ActionSupport {
    private String RadioButtonList1;
    private String checkcode;
    private String username;
    private String password;

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setRadioButtonList1(String radioButtonList1) {
        RadioButtonList1 = radioButtonList1;
    }

    public void setCheckcode(String checkcode) {
        this.checkcode = checkcode;
    }

    public String login() {
        String key = (String) ServletActionContext.getRequest().getSession().getAttribute("key");
        if (StringUtils.isNotBlank(checkcode) && checkcode.equals(key)) {
            //构造一个subject对象
            Subject subject = SecurityUtils.getSubject();
            //构造一个用户名密码令牌
            AuthenticationToken token = new UsernamePasswordToken(username, password);
            try {
                subject.login(token);
            } catch (UnknownAccountException e) {
                e.printStackTrace();
                this.addActionError(this.getText("usernamenotfound"));
                return "login";
            } catch (Exception e) {
                e.printStackTrace();
                this.addActionError(this.getText("loginError"));
                return "login";
            }
            //获取认证信息中存储的对象
            Object user = subject.getPrincipal();
            boolean permittedAll = subject.isPermittedAll();
              /*  User login = userService.login(model);*/
            if (RadioButtonList1.equals("访客")) {
                if (user instanceof User) {
                    if (user != null) {
                        ServletActionContext.getRequest().getSession().setAttribute("user", user);
                        return "list";
                    } else {
                        this.addActionError(this.getText("loginError"));
                        return "login";
                    }
                } else {
                    this.addActionError(this.getText("usernamenotfound"));
                    return "list";
                }
            } else if (RadioButtonList1.equals("教师")) {
                if (user instanceof Teacher) {
                    if (user != null) {
                        ServletActionContext.getRequest().getSession().setAttribute("teacher", user);
                        return "list";
                    } else {
                        this.addActionError(this.getText("loginError"));
                        return "login";
                    }
                } else {
                    this.addActionError(this.getText("usernamenotfound"));
                    return "login";
                }
            } else if (RadioButtonList1.equals("学生")) {
                if (user instanceof Student) {
                    if (user != null) {
                        ServletActionContext.getRequest().getSession().setAttribute("student", user);
                        return "list";
                    } else {
                        this.addActionError(this.getText("loginError"));
                        return "login";
                    }
                } else {
                    this.addActionError(this.getText("usernamenotfound"));
                    return "login";
                }
            }
        } else {
            this.addActionError(this.getText("validateCodeError"));
        }
        return "login";
    }
}
