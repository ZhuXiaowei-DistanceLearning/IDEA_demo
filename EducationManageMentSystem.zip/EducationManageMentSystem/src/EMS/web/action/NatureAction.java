package EMS.web.action;

import EMS.domain.Nature;
import EMS.web.action.base.BaseAction;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import java.io.IOException;
import java.util.List;

/**
 * Created by Administrator on 2017/6/19.
 */
@Controller
@Scope("prototype")
public class NatureAction extends BaseAction<Nature> {
    public String listajax() throws IOException {
        List<Nature> list = natureService.findAll();
        this.writeList2Json(list, new String[]{"courses"});
        return NONE;
    }
}
