package EMS.web.action;

import EMS.domain.College;
import EMS.service.CollegeService;
import EMS.web.action.base.BaseAction;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import java.io.IOException;
import java.util.List;

/**
 * Created by Administrator on 2017/6/17.
 */
@Controller
@Scope("prototype")
public class CollegeAction extends BaseAction<College> {
    /**
     * 分页查询
     *
     * @return
     * @throws IOException
     */
    public String pageQuery() throws IOException {
        collegeService.pageQuery(pageBean);
        this.writePageBean2Json(pageBean, new String[]{"teachers", "specialties", "currentPage", "detachedCriteria", "pageSize"});
        return NONE;
    }

    /**
     * 增加学院
     *
     * @return
     */
    public String addCollege() {
        collegeService.save(model);
        return "list";
    }

    private String ids;

    public void setIds(String ids) {
        this.ids = ids;
    }

    /**
     * 删除学院
     *
     * @return
     */
    public String delete() {
        collegeService.delete(ids);
        return "list";
    }

    /**
     * 修改学院
     *
     * @return
     */
    public String editCollege() {
        collegeService.edit(model);
        return "list";
    }

    /**
     * 查询列表
     */
    public String listajax() throws IOException {
        List<College> list = collegeService.findListNostatus();
        this.writeList2Json(list, new String[]{"teachers", "specialties"});
        return NONE;
    }
}
