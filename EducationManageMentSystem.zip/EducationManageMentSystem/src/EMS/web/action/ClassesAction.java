package EMS.web.action;

import EMS.domain.Classes;
import EMS.domain.College;
import EMS.web.action.base.BaseAction;
import org.apache.struts2.ServletActionContext;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import java.io.IOException;
import java.util.List;

/**
 * Created by Administrator on 2017/6/17.
 */
@Controller
@Scope("prototype")
public class ClassesAction extends BaseAction<Classes> {
    /**
     * 分页查询
     *
     * @return
     * @throws IOException
     */
    public String pageQuery() throws IOException {
        classesSerivce.pageQuery(pageBean);
        this.writePageBean2Json(pageBean, new String[]{"currentPage", "detachedCriteria", "pageSize", "students", "classeses", "college"});
        return NONE;
    }

    public String add() {
        classesSerivce.save(model);
        return "list";
    }

    private String ids;

    public void setIds(String ids) {
        this.ids = ids;
    }

    public String findById() {
        Classes classes_id = classesSerivce.findById(ids);
        ServletActionContext.getRequest().getSession().setAttribute("classes_id", classes_id);
        return "page";
    }

    /**
     * 查询列表
     */
    public String listajax() throws IOException {
        List<College> list = collegeService.findListNostatus();
        this.writeList2Json(list, new String[]{"teachers", "specialties"});
        return NONE;
    }
}
