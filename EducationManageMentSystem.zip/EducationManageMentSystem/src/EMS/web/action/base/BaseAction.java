package EMS.web.action.base;

import EMS.domain.Score;
import EMS.service.*;
import EMS.utils.PageBean;
import EMS.web.action.ClassesAction;
import EMS.web.action.WeekAction;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;
import org.apache.poi.ss.formula.functions.T;
import org.apache.struts2.ServletActionContext;
import org.hibernate.criterion.DetachedCriteria;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.IOException;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.List;

/**
 * Created by Administrator on 2017/6/16.
 */
public class BaseAction<T> extends ActionSupport implements ModelDriven<T> {
    @Autowired
    protected UserService userService;
    @Autowired
    protected CollegeService collegeService;
    @Autowired
    protected SpecialtyService specialtyService;
    @Autowired
    protected ClassesSerivce classesSerivce;
    @Autowired
    protected StudentService studentService;
    @Autowired
    protected TeacherService teacherService;
    @Autowired
    protected CourseService courseService;
    @Autowired
    protected WeekService weekService;
    @Autowired
    protected SectionService sectionService;
    @Autowired
    protected FunctionService functionService;
    @Autowired
    protected RoleSerivce roleSerivce;
    @Autowired
    protected ScoreService scoreService;
    @Autowired
    protected NatureService natureService;

    protected T model;

    protected PageBean pageBean = new PageBean();
    private DetachedCriteria detachedCriteria = null;
    private int page;
    private int rows;

    @Override
    public T getModel() {
        return model;
    }

    public void setPage(int page) {
        pageBean.setCurrentPage(page);
    }

    public void setRows(int rows) {
        pageBean.setPageSize(rows);
    }

    public BaseAction() {
        System.out.println(this.getClass());
        ParameterizedType genericSuperclass = (ParameterizedType) this.getClass().getGenericSuperclass();
        Type[] actualTypeArguments = genericSuperclass.getActualTypeArguments();
        Class<T> tClass = (Class<T>) actualTypeArguments[0];
        detachedCriteria = DetachedCriteria.forClass(tClass);
        pageBean.setDetachedCriteria(detachedCriteria);
        try {
            model = tClass.newInstance();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    public void writePageBean2Json(PageBean pageBean, String[] excludes) throws IOException {
        JsonConfig jsonConfig = new JsonConfig();
        jsonConfig.setExcludes(excludes);
        //将PageBean对象转为json对象
        JSONObject jsonObject = JSONObject.fromObject(pageBean, jsonConfig);
        System.out.println("jsonConfig" + jsonConfig);
        String json = jsonObject.toString();
        System.out.println("json" + json);
        ServletActionContext.getResponse().setContentType("text/json;charset=utf-8");
        ServletActionContext.getResponse().getWriter().print(json);
    }

    public void writeList2Json(List list, String[] excludes) throws IOException {
        JsonConfig jsonConfig = new JsonConfig();
        jsonConfig.setExcludes(excludes);
        JSONArray jsonObject = JSONArray.fromObject(list, jsonConfig);
        String json = jsonObject.toString();
        ServletActionContext.getResponse().setContentType("text/json;charset=utf-8");
        ServletActionContext.getResponse().getWriter().print(json);
    }
}
