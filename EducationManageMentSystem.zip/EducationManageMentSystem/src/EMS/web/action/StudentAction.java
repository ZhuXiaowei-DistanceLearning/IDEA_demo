package EMS.web.action;

import EMS.domain.Classes;
import EMS.domain.Role;
import EMS.domain.Student;
import EMS.service.StudentService;
import EMS.web.action.base.BaseAction;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.struts2.ServletActionContext;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017/6/17.
 */
@Controller
@Scope("prototype")
public class StudentAction extends BaseAction<Student> {
    private File myFile;

    public void setMyFile(File myFile) {
        this.myFile = myFile;
    }

    public String importXls() throws Exception {
        Classes classes = (Classes) ServletActionContext.getRequest().getSession().getAttribute("classes_id");
        String flag = "1";
        try {
            //获取HSSFWorkbook对象
            HSSFWorkbook workbook = new HSSFWorkbook(new FileInputStream(myFile));
            //getSheetAt，获取HSSFSheet
            HSSFSheet sheet = workbook.getSheetAt(0);
            System.out.println(sheet.getLastRowNum());
            List<Student> list = new ArrayList<Student>();
            //Row接收HSSFSheet对象的值
            for (Row row : sheet) {
                int rowNum = row.getRowNum();
                if (rowNum == 0) {
                    continue;
                }
                HSSFCell cell = (HSSFCell) row.getCell(0);
                cell.setCellType(HSSFCell.CELL_TYPE_STRING);
                String sid = cell.getStringCellValue();
                HSSFCell cell2 = (HSSFCell) row.getCell(1);
                cell2.setCellType(HSSFCell.CELL_TYPE_STRING);
                String password = cell2.getStringCellValue();
                String sname = row.getCell(2).getStringCellValue();
                String sex = row.getCell(3).getStringCellValue();
                String scity = row.getCell(4).getStringCellValue();
                String qx = "学生";
                Student student = new Student(sid, password, sname, sex, scity, qx, classes, null);
                String roleId = "8a6ebaad5cbf6d3b015cbfa6e5430002";
                list.add(student);
                Role role = new Role(roleId);
                student.getRoles().add(role);
            }
            studentService.saveBatch(list);
        } catch (Exception e) {
            flag = "0";
        }
        ServletActionContext.getResponse().setContentType("text/json;charset=utf-8");
        ServletActionContext.getResponse().getWriter().print(flag);
        return "studentInfo";
    }

    public String pageQuery() throws IOException {
        studentService.pageQuery(pageBean);
        this.writePageBean2Json(pageBean, new String[]{"currentPage", "detachedCriteria", "pageSize", "scores", "students", "specialty", "roles"});
        return NONE;
    }

    public String listajax() throws IOException {
        List<Student> students = studentService.findAll();
        this.writeList2Json(students, new String[]{"scores", "classes", "roles"});
        return NONE;
    }

    public String findStudentByclass() throws IOException {
        Classes classes = (Classes) ServletActionContext.getRequest().getSession().getAttribute("classes_id");
        System.out.println(classes.getId());
        List<Student> list = studentService.findStudentById(pageBean, classes.getId());
        this.writeList2Json(list, new String[]{"currentPage", "detachedCriteria", "pageSize", "scores", "students", "specialty", "roles"});
        return NONE;
    }

    private String[] studentIds;

    public void setStudentIds(String[] studentIds) {
        this.studentIds = studentIds;
    }

    public String addAbsent() {
        studentService.addStudentAbenst(model.getAbsent(), studentIds);
        return "teacherlist";
    }
}
