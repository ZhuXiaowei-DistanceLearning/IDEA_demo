package EMS.web.action;

import EMS.domain.Week;
import EMS.web.action.base.BaseAction;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import java.io.IOException;
import java.util.List;

/**
 * Created by Administrator on 2017/6/19.
 */
@Controller
@Scope("prototype")
public class WeekAction extends BaseAction<Week> {
    public String listajax() throws IOException {
        List<Week> list = weekService.findAll();
        this.writeList2Json(list, new String[]{"courses"});
        return NONE;
    }
}
