package EMS.shiro;

import EMS.dao.FunctionDao;
import EMS.dao.StudentDao;
import EMS.dao.TeacherDao;
import EMS.dao.UserDao;
import EMS.domain.Function;
import EMS.domain.Student;
import EMS.domain.Teacher;
import EMS.domain.User;
import com.opensymphony.xwork2.validator.annotations.RequiredStringValidator;
import org.apache.shiro.authc.*;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by Administrator on 2017/6/19.
 */
public class EMSshiro extends AuthorizingRealm {
    @Resource
    private UserDao userDao;
    @Resource
    private TeacherDao teacherDao;
    @Resource
    private StudentDao studentDao;
    @Resource
    private FunctionDao functionDao;

    /**
     * 授权方法
     *
     * @param principalCollection
     * @return
     */
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {
        SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();
        Object object = principalCollection.getPrimaryPrincipal();
        List<Function> list = null;
        if (object instanceof User) {
            User user = (User) object;
            list = functionDao.findAll();
        } else if (object instanceof Teacher) {
            Teacher teacher = (Teacher) object;
            if (teacher.getQx().equals("院长")) {
                info.addStringPermission("yz");
            }
            list = functionDao.findListByTeacherid(teacher.getTid());
        } else if (object instanceof Student) {
            Student student = (Student) object;
            list = functionDao.findListByStudentid(student.getSid());
        }
        for (Function function : list) {
            info.addStringPermission(function.getCode());
        }
        return info;
    }

    /**
     * 认证方法
     *
     * @param token
     * @return
     * @throws AuthenticationException
     */
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthenticationException {
        UsernamePasswordToken upToken = (UsernamePasswordToken) token;
        String username = upToken.getUsername();
        User user = userDao.findByUsername(username);
        Teacher teacher = teacherDao.findByUsername(username);
        Student student = studentDao.findByUsername(username);
        if (user != null) {
            String password = user.getPassword();
            SimpleAuthenticationInfo info = new SimpleAuthenticationInfo(user, password, this.getClass().getSimpleName());
            return info;
        } else if (teacher != null) {
            String password = teacher.getPassword();
            SimpleAuthenticationInfo info = new SimpleAuthenticationInfo(teacher, password, this.getClass().getSimpleName());
            return info;
        } else if (student == null) {
            return null;
        }
        String password = student.getPassword();
        SimpleAuthenticationInfo info = new SimpleAuthenticationInfo(student, password, this.getClass().getSimpleName());
        return info;
    }
}
