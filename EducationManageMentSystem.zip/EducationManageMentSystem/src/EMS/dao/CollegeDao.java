package EMS.dao;

import EMS.dao.base.BaseDao;
import EMS.domain.College;

/**
 * Created by Administrator on 2017/6/17.
 */
public interface CollegeDao extends BaseDao<College> {

}
