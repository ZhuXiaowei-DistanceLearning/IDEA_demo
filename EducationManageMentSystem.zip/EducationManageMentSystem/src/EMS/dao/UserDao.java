package EMS.dao;

import EMS.dao.base.BaseDao;
import EMS.domain.User;

/**
 * Created by Administrator on 2017/6/16.
 */
public interface UserDao extends BaseDao<User> {
    public User login(String username, String password);

    public User findByUsername(String username);
}
