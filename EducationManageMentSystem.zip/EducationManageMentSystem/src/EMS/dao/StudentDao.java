package EMS.dao;

import EMS.dao.base.BaseDao;
import EMS.domain.Student;
import EMS.utils.PageBean;

import java.util.List;

/**
 * Created by Administrator on 2017/6/17.
 */
public interface StudentDao extends BaseDao<Student> {
    public Student findByUsername(String username);

    List<Student> findStudentById(PageBean pageBean, String id);
}
