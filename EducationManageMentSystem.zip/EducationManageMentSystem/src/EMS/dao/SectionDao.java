package EMS.dao;

import EMS.dao.base.BaseDao;
import EMS.domain.Section;

/**
 * Created by Administrator on 2017/6/18.
 */
public interface SectionDao extends BaseDao<Section> {
}
