package EMS.dao;

import EMS.dao.base.BaseDao;
import EMS.domain.Course;
import EMS.utils.PageBean;

import java.util.List;

/**
 * Created by Administrator on 2017/6/18.
 */
public interface CourseDao extends BaseDao<Course> {
    public List<Course> findCourseByteacherId(PageBean pageBean, String tid);
}
