package EMS.dao;

import EMS.dao.base.BaseDao;
import EMS.domain.Classes;

/**
 * Created by Administrator on 2017/6/17.
 */
public interface ClassesDao extends BaseDao<Classes> {
}
