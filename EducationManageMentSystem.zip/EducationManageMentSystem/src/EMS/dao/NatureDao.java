package EMS.dao;

import EMS.dao.base.BaseDao;
import EMS.domain.Nature;

/**
 * Created by Administrator on 2017/6/19.
 */
public interface NatureDao extends BaseDao<Nature> {
}
