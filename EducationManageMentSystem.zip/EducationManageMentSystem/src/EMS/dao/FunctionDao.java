package EMS.dao;


import EMS.dao.base.BaseDao;
import EMS.domain.Function;

import java.util.List;

/**
 * Created by Administrator on 2017/6/11.
 */
public interface FunctionDao extends BaseDao<Function> {
    public List<Function> findListByTeacherid(String userid);

    public List<Function> findAllMenu();

    public List<Function> findMenuByTeacherid(String id);

    public List<Function> findMenuByStudentid(String id);

    public List<Function> findListByStudentid(String userid);

    public List<Function> findListByUserid(String userid);
}
