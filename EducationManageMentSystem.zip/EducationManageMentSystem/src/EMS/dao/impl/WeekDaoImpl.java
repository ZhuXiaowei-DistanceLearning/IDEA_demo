package EMS.dao.impl;

import EMS.dao.WeekDao;
import EMS.dao.base.BaseDao;
import EMS.dao.base.BaseDaoImpl;
import EMS.domain.Week;
import org.springframework.stereotype.Repository;

/**
 * Created by Administrator on 2017/6/18.
 */
@Repository
public class WeekDaoImpl extends BaseDaoImpl<Week> implements WeekDao {
}
