package EMS.dao.impl;

import EMS.dao.NatureDao;
import EMS.dao.base.BaseDaoImpl;
import EMS.domain.Nature;
import org.springframework.stereotype.Repository;

/**
 * Created by Administrator on 2017/6/19.
 */
@Repository
public class NatureDaoImpl extends BaseDaoImpl<Nature> implements NatureDao {
}
