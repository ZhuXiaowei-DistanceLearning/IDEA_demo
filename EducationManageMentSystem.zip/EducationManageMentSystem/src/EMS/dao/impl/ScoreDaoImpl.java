package EMS.dao.impl;

import EMS.dao.ScoreDao;
import EMS.dao.base.BaseDaoImpl;
import EMS.domain.Score;
import EMS.utils.PageBean;
import EMS.web.action.base.BaseAction;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by Administrator on 2017/6/20.
 */
@Repository
public class ScoreDaoImpl extends BaseDaoImpl<Score> implements ScoreDao {
    @Override
    public List<Score> findClassesStudent(PageBean pageBean, String studentId) {
        int Currentpage = pageBean.getCurrentPage();
        int pageSize = pageBean.getPageSize();
        DetachedCriteria detachedCriteria = pageBean.getDetachedCriteria();
        detachedCriteria.setProjection(Projections.rowCount());
        List<Long> list = this.getHibernateTemplate().findByCriteria(detachedCriteria);
        Long aLong = list.get(0);
        pageBean.setTotal(aLong.intValue());
        detachedCriteria.setProjection(null);
        detachedCriteria.setResultTransformer(DetachedCriteria.ROOT_ENTITY);
        int firstResult = (Currentpage - 1) * pageSize;
        int maxResult = pageSize;
        //调用分页查询的方法，需要从第一条数据开始查，每页需要查询的数量
        detachedCriteria.add(Restrictions.eq("id.course.id", studentId));
        List rows = this.getHibernateTemplate().findByCriteria(detachedCriteria);
        pageBean.setRows(rows);
        return rows;
    }
}
