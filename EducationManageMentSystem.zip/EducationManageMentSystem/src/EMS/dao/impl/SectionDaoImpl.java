package EMS.dao.impl;

import EMS.dao.SectionDao;
import EMS.dao.base.BaseDaoImpl;
import EMS.domain.Section;
import org.springframework.stereotype.Repository;

/**
 * Created by Administrator on 2017/6/18.
 */
@Repository
public class SectionDaoImpl extends BaseDaoImpl<Section> implements SectionDao {
}
