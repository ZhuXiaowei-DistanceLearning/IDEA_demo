package EMS.dao.impl;

import EMS.dao.RoleDao;
import EMS.dao.base.BaseDaoImpl;
import EMS.domain.Role;
import org.springframework.stereotype.Repository;

/**
 * Created by Administrator on 2017/6/12.
 */
@Repository
public class RoleDaoImpl extends BaseDaoImpl<Role> implements RoleDao {
}
