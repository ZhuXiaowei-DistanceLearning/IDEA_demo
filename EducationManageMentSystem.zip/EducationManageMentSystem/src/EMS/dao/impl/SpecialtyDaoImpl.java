package EMS.dao.impl;

import EMS.dao.SpecialtyDao;
import EMS.dao.base.BaseDaoImpl;
import EMS.domain.Specialty;
import org.springframework.stereotype.Repository;

/**
 * Created by Administrator on 2017/6/17.
 */
@Repository
public class SpecialtyDaoImpl extends BaseDaoImpl<Specialty> implements SpecialtyDao {
}
