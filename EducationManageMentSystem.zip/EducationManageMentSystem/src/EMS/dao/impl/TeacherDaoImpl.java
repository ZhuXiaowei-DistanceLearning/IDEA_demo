package EMS.dao.impl;

import EMS.dao.TeacherDao;
import EMS.dao.base.BaseDaoImpl;
import EMS.domain.Teacher;
import EMS.web.action.base.BaseAction;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by Administrator on 2017/6/18.
 */
@Repository
public class TeacherDaoImpl extends BaseDaoImpl<Teacher> implements TeacherDao {
    @Override
    public Teacher findByUsername(String username) {
        List<Teacher> list = this.getHibernateTemplate().find("FROM Teacher WHERE tid = ?", username);
        if (list.size() == 1) {
            return list.get(0);
        }
        return null;
    }
}
