package EMS.dao.impl;

import EMS.dao.FunctionDao;
import EMS.dao.base.BaseDaoImpl;
import EMS.domain.Function;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by Administrator on 2017/6/11.
 */
@Repository
public class FunctionDaoImpl extends BaseDaoImpl<Function> implements FunctionDao {
    /**
     * 根据用户id查询对应的权限
     *
     * @param id
     * @return
     */
    @Override
    public List<Function> findListByTeacherid(String userid) {
        String hql = "SELECT DISTINCT f FROM Function f LEFT OUTER JOIN f.roles r" +
                " LEFT OUTER JOIN r.teachers t WHERE t.id = ? ";
        return this.getHibernateTemplate().find(hql, userid);
    }

    public List<Function> findListByStudentid(String userid) {
        String hql = "SELECT DISTINCT f FROM Function f LEFT OUTER JOIN f.roles r" +
                " LEFT OUTER JOIN r.students s WHERE s.id = ? ";
        return this.getHibernateTemplate().find(hql, userid);
    }

    public List<Function> findListByUserid(String userid) {
        String hql = "SELECT DISTINCT f FROM Function f LEFT OUTER JOIN f.roles r" +
                " LEFT OUTER JOIN r.user s WHERE s.id = ? ";
        return this.getHibernateTemplate().find(hql, userid);
    }

    @Override
    public List<Function> findAllMenu() {
        String hql = "FROM Function f WHERE f.generatemenu = '1' ORDER BY f.zindex DESC";
        return this.getHibernateTemplate().find(hql);
    }

    public List<Function> findMenuByTeacherid(String id) {
        String hql = "SELECT DISTINCT f FROM Function f LEFT OUTER JOIN f.roles r" +
                " LEFT OUTER JOIN r.teachers u WHERE u.id = ? AND f.generatemenu = '1' ORDER BY f.zindex DESC ";
        return this.getHibernateTemplate().find(hql, id);
    }

    public List<Function> findMenuByStudentid(String id) {
        String hql = "SELECT DISTINCT f FROM Function f LEFT OUTER JOIN f.roles r" +
                " LEFT OUTER JOIN r.students u WHERE u.id = ? AND f.generatemenu = '1' ORDER BY f.zindex DESC ";
        return this.getHibernateTemplate().find(hql, id);
    }
}
