package EMS.dao.impl;

import EMS.dao.CollegeDao;
import EMS.dao.base.BaseDaoImpl;
import EMS.domain.College;
import org.springframework.stereotype.Repository;

/**
 * Created by Administrator on 2017/6/17.
 */
@Repository
public class CollegeDaoImpl extends BaseDaoImpl<College> implements CollegeDao {

}
