package EMS.dao;


import EMS.dao.base.BaseDao;
import EMS.domain.Role;

/**
 * Created by Administrator on 2017/6/12.
 */
public interface RoleDao extends BaseDao<Role> {
}
