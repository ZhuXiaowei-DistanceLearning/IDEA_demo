package EMS.dao;

import EMS.dao.base.BaseDao;
import EMS.domain.Teacher;

/**
 * Created by Administrator on 2017/6/18.
 */
public interface TeacherDao extends BaseDao<Teacher> {
    public Teacher findByUsername(String username);
}
