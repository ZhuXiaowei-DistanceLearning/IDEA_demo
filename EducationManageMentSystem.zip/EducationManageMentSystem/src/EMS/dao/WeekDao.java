package EMS.dao;

import EMS.dao.base.BaseDao;
import EMS.domain.Week;

/**
 * Created by Administrator on 2017/6/18.
 */
public interface WeekDao extends BaseDao<Week> {
}
