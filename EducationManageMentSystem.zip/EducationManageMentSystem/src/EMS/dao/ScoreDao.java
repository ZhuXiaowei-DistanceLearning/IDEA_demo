package EMS.dao;

import EMS.dao.base.BaseDao;
import EMS.domain.Score;
import EMS.utils.PageBean;

import java.util.List;

/**
 * Created by Administrator on 2017/6/20.
 */
public interface ScoreDao extends BaseDao<Score> {
    public List<Score> findClassesStudent(PageBean pageBean, String studentId);
}
