package EMS.domain;// default package

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;


/**
 * Teacher entity. @author MyEclipse Persistence Tools
 */

public class Teacher implements java.io.Serializable {


    // Fields    

    private String tid;
    private College college;
    private String password;
    private String tname;
    private String tsex;
    private String tage;
    private String qx;
    private String status = "0";
    private Double salary;
    private Date beginTime;
    private Set courses = new HashSet(0);
    private Set roles = new HashSet(0);

    public String getCollegeName() {
        return college.getName();
    }

    public String getFormatDate() {
        if (beginTime != null) {
            return new SimpleDateFormat("yyyy-MM-dd").format(beginTime);
        } else {
            return "未提交生日";
        }
    }

    // Constructors

    /**
     * default constructor
     */
    public Teacher() {
    }

    /**
     * minimal constructor
     */
    public Teacher(String tid) {
        this.tid = tid;
    }

    /**
     * full constructor
     */
    public Teacher(String tid, College college, String password, String tname, String tsex, String tage, Set courses) {
        this.tid = tid;
        this.college = college;
        this.password = password;
        this.tname = tname;
        this.tsex = tsex;
        this.tage = tage;
        this.courses = courses;
    }


    // Property accessors

    public String getTid() {
        return this.tid;
    }

    public void setTid(String tid) {
        this.tid = tid;
    }

    public College getCollege() {
        return this.college;
    }

    public void setCollege(College college) {
        this.college = college;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getTname() {
        return this.tname;
    }

    public void setTname(String tname) {
        this.tname = tname;
    }

    public String getTsex() {
        return this.tsex;
    }

    public void setTsex(String tsex) {
        this.tsex = tsex;
    }

    public String getTage() {
        return this.tage;
    }

    public void setTage(String tage) {
        this.tage = tage;
    }

    public String getQx() {
        return qx;
    }

    public void setQx(String qx) {
        this.qx = qx;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Double getSalary() {
        return salary;
    }

    public void setSalary(Double salary) {
        this.salary = salary;
    }

    public Date getBeginTime() {
        return beginTime;
    }

    public void setBeginTime(Date beginTime) {
        this.beginTime = beginTime;
    }

    public Set getCourses() {
        return this.courses;
    }

    public void setCourses(Set courses) {
        this.courses = courses;
    }

    public Set getRoles() {
        return roles;
    }

    public void setRoles(Set roles) {
        this.roles = roles;
    }

}