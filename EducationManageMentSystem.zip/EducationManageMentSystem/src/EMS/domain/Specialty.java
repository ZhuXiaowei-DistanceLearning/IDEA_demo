package EMS.domain;// default package

import java.util.HashSet;
import java.util.Set;


/**
 * Specialty entity. @author MyEclipse Persistence Tools
 */

public class Specialty implements java.io.Serializable {


    // Fields    

    private String id;
    private College college;
    private String name;
    private String status = "0";
    private Set classeses = new HashSet(0);

    public String getCollegeName() {
        String names = college.getName();
        return names;
    }

    // Constructors

    /**
     * default constructor
     */
    public Specialty() {
    }

    /**
     * minimal constructor
     */
    public Specialty(String id) {
        this.id = id;
    }

    /**
     * full constructor
     */
    public Specialty(String id, College college, String name, Set classeses) {
        this.id = id;
        this.college = college;
        this.name = name;
        this.classeses = classeses;
    }


    // Property accessors

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public College getCollege() {
        return this.college;
    }

    public void setCollege(College college) {
        this.college = college;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Set getClasseses() {
        return this.classeses;
    }

    public void setClasseses(Set classeses) {
        this.classeses = classeses;
    }


}