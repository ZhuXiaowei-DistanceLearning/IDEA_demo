package EMS.domain;// default package

import java.util.HashSet;
import java.util.Set;


/**
 * Student entity. @author MyEclipse Persistence Tools
 */

public class Student implements java.io.Serializable {


    // Fields    

    private String sid;
    private Classes classes;
    private String password;
    private String sname;
    private String sex;
    private String scity;
    private String qx;
    private Integer absent = 0;
    private Set scores = new HashSet(0);
    private Set roles = new HashSet(0);

    public String getClassname() {
        return classes.getClassname();
    }

    // Constructors

    /**
     * default constructor
     */
    public Student() {
    }

    /**
     * minimal constructor
     */
    public Student(String sid) {
        this.sid = sid;
    }

    /**
     * full constructor
     */
    public Student(String sid, String password, String sname, String sex, String scity, String qx, Classes classes, Set scores) {
        this.sid = sid;
        this.password = password;
        this.sname = sname;
        this.sex = sex;
        this.scity = scity;
        this.qx = qx;
        this.classes = classes;
        this.scores = scores;
    }


    // Property accessors

    public String getSid() {
        return this.sid;
    }

    public void setSid(String sid) {
        this.sid = sid;
    }

    public Classes getClasses() {
        return this.classes;
    }

    public void setClasses(Classes classes) {
        this.classes = classes;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getSname() {
        return this.sname;
    }

    public void setSname(String sname) {
        this.sname = sname;
    }

    public String getSex() {
        return this.sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getScity() {
        return this.scity;
    }

    public void setScity(String scity) {
        this.scity = scity;
    }

    public String getQx() {
        return qx;
    }

    public void setQx(String qx) {
        this.qx = qx;
    }

    public Set getScores() {
        return this.scores;
    }

    public void setScores(Set scores) {
        this.scores = scores;
    }

    public Integer getAbsent() {
        return absent;
    }

    public void setAbsent(Integer absent) {
        this.absent = absent;
    }

    public Set getRoles() {
        return roles;
    }

    public void setRoles(Set roles) {
        this.roles = roles;
    }
}