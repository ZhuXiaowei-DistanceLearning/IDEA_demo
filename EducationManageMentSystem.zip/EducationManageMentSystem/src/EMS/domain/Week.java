package EMS.domain;// default package

import java.util.HashSet;
import java.util.Set;


/**
 * Week entity. @author MyEclipse Persistence Tools
 */

public class Week  implements java.io.Serializable {


    // Fields    

     private String id;
     private String time;
     private Set courses = new HashSet(0);


    // Constructors

    /** default constructor */
    public Week() {
    }

	/** minimal constructor */
    public Week(String id) {
        this.id = id;
    }
    
    /** full constructor */
    public Week(String id, String time, Set courses) {
        this.id = id;
        this.time = time;
        this.courses = courses;
    }

   
    // Property accessors

    public String getId() {
        return this.id;
    }
    
    public void setId(String id) {
        this.id = id;
    }

    public String getTime() {
        return this.time;
    }
    
    public void setTime(String time) {
        this.time = time;
    }

    public Set getCourses() {
        return this.courses;
    }
    
    public void setCourses(Set courses) {
        this.courses = courses;
    }
   








}