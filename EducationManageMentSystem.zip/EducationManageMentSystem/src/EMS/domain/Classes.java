package EMS.domain;// default package

import java.util.HashSet;
import java.util.Set;


/**
 * Classes entity. @author MyEclipse Persistence Tools
 */

public class Classes implements java.io.Serializable {


    // Fields    

    private String id;
    private Specialty specialty;
    private String classname;
    private Set students = new HashSet(0);

    public String getSpecialtyName() {
        return specialty.getName();
    }

    public String getCollegeName() {
        return specialty.getCollegeName();
    }


    // Constructors

    /**
     * default constructor
     */
    public Classes() {
    }

    /**
     * minimal constructor
     */
    public Classes(String id) {
        this.id = id;
    }

    /**
     * full constructor
     */
    public Classes(String id, Specialty specialty, String classname, Set students) {
        this.id = id;
        this.specialty = specialty;
        this.classname = classname;
        this.students = students;
    }


    // Property accessors

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Specialty getSpecialty() {
        return this.specialty;
    }

    public void setSpecialty(Specialty specialty) {
        this.specialty = specialty;
    }

    public String getClassname() {
        return this.classname;
    }

    public void setClassname(String classname) {
        this.classname = classname;
    }

    public Set getStudents() {
        return this.students;
    }

    public void setStudents(Set students) {
        this.students = students;
    }


}