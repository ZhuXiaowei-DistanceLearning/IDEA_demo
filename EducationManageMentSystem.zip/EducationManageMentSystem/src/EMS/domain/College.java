package EMS.domain;// default package

import java.util.HashSet;
import java.util.Set;


/**
 * College entity. @author MyEclipse Persistence Tools
 */

public class College implements java.io.Serializable {


    // Fields    

    private String id;
    private String name;
    private String status = "0";
    private Set teachers = new HashSet(0);
    private Set specialties = new HashSet(0);


    // Constructors

    /**
     * default constructor
     */
    public College() {
    }

    /**
     * minimal constructor
     */
    public College(String id) {
        this.id = id;
    }

    /**
     * full constructor
     */
    public College(String id, String name, Set teachers, Set specialties) {
        this.id = id;
        this.name = name;
        this.teachers = teachers;
        this.specialties = specialties;
    }


    // Property accessors

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Set getTeachers() {
        return this.teachers;
    }

    public void setTeachers(Set teachers) {
        this.teachers = teachers;
    }

    public Set getSpecialties() {
        return this.specialties;
    }

    public void setSpecialties(Set specialties) {
        this.specialties = specialties;
    }


}