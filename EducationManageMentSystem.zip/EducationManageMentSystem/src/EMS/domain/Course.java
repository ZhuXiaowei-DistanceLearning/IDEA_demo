package EMS.domain;// default package

import java.util.HashSet;
import java.util.Set;


/**
 * Course entity. @author MyEclipse Persistence Tools
 */

public class Course implements java.io.Serializable {


    // Fields    

    private String id;
    private Nature nature;
    private Teacher teacher;
    private Section section;
    private Week week;
    private String name;
    private Integer credit;
    private String classroom;
    private Integer totalPeople;
    private Integer people = 0;
    private Set scores = new HashSet(0);

    public String getWeekAnsection() {
        return section.getSectionTime() + "{" + week.getTime() + "}";
    }

    public Course(String id, Integer people) {
        this.id = id;
        this.people = people;
    }


    public String getShowpeople() {
        return people + "/" + totalPeople;
    }

    // Constructors

    /**
     * default constructor
     */
    public Course() {
    }

    /**
     * minimal constructor
     */
    public Course(String id) {
        this.id = id;
    }

    /**
     * full constructor
     */
    public Course(String id, Nature nature, Teacher teacher, Section section, Week week, String name, Integer credit, String classroom, Integer people, Set scores) {
        this.id = id;
        this.nature = nature;
        this.teacher = teacher;
        this.section = section;
        this.week = week;
        this.name = name;
        this.credit = credit;
        this.classroom = classroom;
        this.people = people;
        this.scores = scores;
    }


    // Property accessors

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Nature getNature() {
        return this.nature;
    }

    public void setNature(Nature nature) {
        this.nature = nature;
    }

    public Teacher getTeacher() {
        return this.teacher;
    }

    public void setTeacher(Teacher teacher) {
        this.teacher = teacher;
    }

    public Section getSection() {
        return this.section;
    }

    public void setSection(Section section) {
        this.section = section;
    }

    public Week getWeek() {
        return this.week;
    }

    public void setWeek(Week week) {
        this.week = week;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getCredit() {
        return this.credit;
    }

    public void setCredit(Integer credit) {
        this.credit = credit;
    }

    public String getClassroom() {
        return this.classroom;
    }

    public void setClassroom(String classroom) {
        this.classroom = classroom;
    }

    public Integer getPeople() {
        return this.people;
    }

    public void setPeople(Integer people) {
        this.people = people;
    }

    public Set getScores() {
        return this.scores;
    }

    public void setScores(Set scores) {
        this.scores = scores;
    }

    public Integer getTotalPeople() {
        return totalPeople;
    }

    public void setTotalPeople(Integer totalPeople) {
        this.totalPeople = totalPeople;
    }
}