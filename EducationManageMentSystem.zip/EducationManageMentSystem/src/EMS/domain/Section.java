package EMS.domain;// default package

import java.util.HashSet;
import java.util.Set;


/**
 * Section entity. @author MyEclipse Persistence Tools
 */

public class Section implements java.io.Serializable {


    // Fields    

    private String id;
    private String week;
    private String section;
    private Set courses = new HashSet(0);

    public String getSectionTime() {
        return week + " " + section;
    }
    // Constructors

    /**
     * default constructor
     */
    public Section() {
    }

    /**
     * minimal constructor
     */
    public Section(String id) {
        this.id = id;
    }

    /**
     * full constructor
     */
    public Section(String id, String week, String section, Set courses) {
        this.id = id;
        this.week = week;
        this.section = section;
        this.courses = courses;
    }


    // Property accessors

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getWeek() {
        return this.week;
    }

    public void setWeek(String week) {
        this.week = week;
    }

    public String getSection() {
        return this.section;
    }

    public void setSection(String section) {
        this.section = section;
    }

    public Set getCourses() {
        return this.courses;
    }

    public void setCourses(Set courses) {
        this.courses = courses;
    }


}